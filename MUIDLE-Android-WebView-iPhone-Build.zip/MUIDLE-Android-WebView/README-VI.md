# MUI DLE Manager – Android WebView APK

Ứng dụng Android mở trực tiếp website:
https://hoainiem2003.net/muidle

## Cách build chỉ bằng iPhone

1. Tải và giải nén file ZIP này trong ứng dụng Tệp (Files) hoặc dùng trang web giải nén.
2. Đăng nhập GitHub trên Safari và tạo một repository mới, ví dụ `muidle-android`.
3. Tải toàn bộ nội dung bên trong thư mục `MUIDLE-Android-WebView` lên repository, giữ nguyên cấu trúc thư mục.
4. Mở tab **Actions** của repository.
5. Chọn workflow **Build MUI DLE APK** và nhấn **Run workflow** (hoặc chờ build tự chạy sau khi upload).
6. Khi build hoàn tất, mở lần chạy mới nhất, kéo xuống **Artifacts**, tải `MUIDLE-Manager-APK`.
7. Giải nén artifact để lấy `app-debug.apk`.

## Lưu ý

- Đây là APK debug để cài thử, không phải bản phát hành Play Store.
- APK debug được ký bằng debug key tự động; khi phát hành lâu dài nên tạo keystore riêng và build bản release.
- Android WebView sử dụng WebView hệ thống trên thiết bị Android.
- Một số chức năng đặc biệt của website (ví dụ tải tệp, chọn ảnh, cửa sổ popup hoặc thông báo đẩy) có thể cần bổ sung xử lý riêng sau khi kiểm tra thực tế.
